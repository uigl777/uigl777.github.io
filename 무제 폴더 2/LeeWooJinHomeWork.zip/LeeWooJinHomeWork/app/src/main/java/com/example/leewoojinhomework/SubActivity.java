package com.example.leewoojinhomework;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class SubActivity extends Activity{
@Override
protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub); //R 은 리소스 아래 layout 에 activitymain 이 있다
        }
        public void onClick(View view) {
            finish();
        }
}
